"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_orderlist_orderlist_module_ts"],{

/***/ 800:
/*!*******************************************************!*\
  !*** ./src/app/orderlist/orderlist-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderlistPageRoutingModule": () => (/* binding */ OrderlistPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _orderlist_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./orderlist.page */ 7929);




const routes = [
    {
        path: '',
        component: _orderlist_page__WEBPACK_IMPORTED_MODULE_0__.OrderlistPage
    }
];
let OrderlistPageRoutingModule = class OrderlistPageRoutingModule {
};
OrderlistPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OrderlistPageRoutingModule);



/***/ }),

/***/ 155:
/*!***********************************************!*\
  !*** ./src/app/orderlist/orderlist.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderlistPageModule": () => (/* binding */ OrderlistPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _orderlist_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./orderlist-routing.module */ 800);
/* harmony import */ var _orderlist_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./orderlist.page */ 7929);







let OrderlistPageModule = class OrderlistPageModule {
};
OrderlistPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _orderlist_routing_module__WEBPACK_IMPORTED_MODULE_0__.OrderlistPageRoutingModule
        ],
        declarations: [_orderlist_page__WEBPACK_IMPORTED_MODULE_1__.OrderlistPage]
    })
], OrderlistPageModule);



/***/ }),

/***/ 7929:
/*!*********************************************!*\
  !*** ./src/app/orderlist/orderlist.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderlistPage": () => (/* binding */ OrderlistPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _orderlist_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./orderlist.page.html?ngResource */ 2421);
/* harmony import */ var _orderlist_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./orderlist.page.scss?ngResource */ 3128);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/service.service */ 58);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/toast.service */ 4465);







let OrderlistPage = class OrderlistPage {
    constructor(service, modalController, toast, alertController) {
        this.service = service;
        this.modalController = modalController;
        this.toast = toast;
        this.alertController = alertController;
        this.orders = [];
    }
    ngOnInit() {
        this.getorders();
    }
    dismiss() {
        this.modalController.dismiss();
    }
    getorders() {
        this.load = true;
        this.service.get("getOrders").subscribe((response) => {
            if (response.success === true) {
                this.load = false;
                this.orders = [];
                for (let post of response.results) {
                    this.orders.push(post);
                }
            }
        });
    }
    sendSms(mes) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            let alert = this.alertController.create({
                header: "Send SMS",
                inputs: [
                    {
                        name: 'message',
                        placeholder: 'ENTER MESSAGE'
                    },
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: data => {
                            console.log('Cancel clicked');
                        }
                    },
                    {
                        text: 'SUBMIT',
                        handler: data => {
                            let body = {
                                number: mes.phone,
                                message: data.message
                            };
                            this.service.post(body, "sms").subscribe((res) => {
                                if (res.success === true) {
                                    this.toast.presentToast("Success");
                                }
                            });
                        }
                    }
                ]
            });
            (yield alert).present();
        });
    }
    deliver(post) {
        this.alertController.create({
            header: 'Confirm',
            message: 'Do you want to deliver this item?',
            buttons: [
                {
                    text: 'No',
                    handler: () => {
                        console.log(post);
                    }
                },
                {
                    text: 'Yes!',
                    handler: () => {
                        let body = {
                            id: post.id,
                            tablename: 'orders'
                        };
                        this.service.post(body, "updateState").subscribe((response) => {
                            if (response.success === true) {
                                const index = this.orders.indexOf(post);
                                this.orders.splice(index, 1);
                            }
                        });
                    }
                }
            ]
        }).then(res => {
            res.present();
        });
    }
};
OrderlistPage.ctorParameters = () => [
    { type: _services_service_service__WEBPACK_IMPORTED_MODULE_2__.ServiceService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_3__.ToastService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController }
];
OrderlistPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-orderlist',
        template: _orderlist_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_orderlist_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], OrderlistPage);



/***/ }),

/***/ 58:
/*!*********************************************!*\
  !*** ./src/app/services/service.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceService": () => (/* binding */ ServiceService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 6587);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 7418);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../environments/environment */ 2340);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);







let ServiceService = class ServiceService {
    constructor(http, alertController) {
        this.http = http;
        this.alertController = alertController;
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders().set('Content-Type', 'application/json');
        this.apiUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url;
        this.server = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.server;
        console.log(this.apiUrl);
    }
    imgError(e) {
        e.target.src = '../../assets/icon/no-image-icon.png';
    }
    alert(header, message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: header,
                message: message,
                buttons: [
                    {
                        text: 'OK',
                        handler: () => {
                        }
                    }
                ]
            });
            alert.present();
        });
    }
    loginUser(data) {
        let API_URL = `${this.apiUrl}/login.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    post(data, file) {
        let API_URL = `${this.apiUrl}` + file + '.php';
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    get(filename) {
        //  this.url = '?_page=' + this.page_number + '&_limit=' + this.page_limit;
        let API_URL = `${this.apiUrl}` + filename + '.php';
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getId(id, file) {
        return this.http.get(`${this.apiUrl}` + file + '.php?id=' + `${id}`);
    }
    put(data, file) {
        let API_URL = `${this.apiUrl}` + file + '.php';
        return this.http.put(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    verifyUser(data) {
        let API_URL = `${this.apiUrl}/verify.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    addUser(data) {
        let API_URL = `${this.apiUrl}/register.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    updPhotoUser(data) {
        let API_URL = `${this.apiUrl}/cover.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    addItems(data) {
        let API_URL = `${this.apiUrl}/additems.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getCinfo(data) {
        let API_URL = `${this.apiUrl}/getinfo.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    updateUser(data) {
        let API_URL = `${this.apiUrl}/edituser.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    closeday(data) {
        let API_URL = `${this.apiUrl}/closeday.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    addCashout(data) {
        let API_URL = `${this.apiUrl}/cashout.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getItems() {
        let API_URL = `${this.apiUrl}/getitems.php`;
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getDItems() {
        let API_URL = `${this.apiUrl}/getditems.php`;
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getdailies() {
        let API_URL = `${this.apiUrl}/dailies.php`;
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    addsales(data) {
        let API_URL = `${this.apiUrl}/sellitem.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getsales() {
        let API_URL = `${this.apiUrl}/loadsales.php`;
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    addexpense(data) {
        let API_URL = `${this.apiUrl}/expenses.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    setup(data) {
        let API_URL = `${this.apiUrl}/setup.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    productkey(data) {
        let API_URL = `${this.apiUrl}/productkey.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    deleteItem(data) {
        let API_URL = `${this.apiUrl}/delete_item.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    returnItem(data) {
        let API_URL = `${this.apiUrl}/return.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getUsers() {
        let API_URL = `${this.apiUrl}/getUsers.php`;
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getsingleitem(itemnum) {
        let API_URL = `${this.apiUrl}/singleitem.php`;
        return this.http.post(API_URL, itemnum)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getcustomer(id) {
        return this.http.get(`${this.apiUrl}/loadsinglecustomer.php?id=${id}`, id);
    }
    // Handle Errors 
    error(error) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            errorMessage = error.error.message;
        }
        else {
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.log(errorMessage);
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(errorMessage);
    }
};
ServiceService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController }
];
ServiceService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], ServiceService);



/***/ }),

/***/ 4465:
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ToastService": () => (/* binding */ ToastService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 3819);



let ToastService = class ToastService {
    constructor(toastController) {
        this.toastController = toastController;
    }
    presentToast(infoMessage) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: infoMessage,
                duration: 2000,
                position: 'top'
            });
            toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ToastController }
];
ToastService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], ToastService);



/***/ }),

/***/ 3128:
/*!**********************************************************!*\
  !*** ./src/app/orderlist/orderlist.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJvcmRlcmxpc3QucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 2421:
/*!**********************************************************!*\
  !*** ./src/app/orderlist/orderlist.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons>\n      <ion-button (click)=\"dismiss()\">\n        <ion-icon name=\"close\" color=\"danger\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Orderlist  {{orders.length}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<!--   <div class=\"row mt-5\">\n    <div class=\"col-xl-8 mb-5 mb-xl-0\">\n      <div class=\"card shadow\">\n        <div class=\"card-header border-0\">\n          <div class=\"row align-items-center\">\n            <div class=\"col\">\n              <h3 class=\"mb-0\">Recent Orders</h3>\n            </div>\n           \n          </div>\n        </div>\n        <div class=\"table-responsive\" style=\"overflow-x:auto ;\">\n         \n          <table class=\"table align-items-center table-flush\">\n            <thead class=\"thead-light\">\n              <tr>\n                <th scope=\"col\">Item</th>\n                <th scope=\"col\">Quantity</th>\n                <th scope=\"col\">Cost</th>\n                <th scope=\"col\">Table</th>\n                <th scope=\"col\">Price</th>\n                <th scope=\"col\">Time</th>\n                <th scope=\"col\">Status</th>\n              </tr>\n            </thead>\n            <tbody *ngFor=\"let i of orders\">\n              <tr>\n                <th scope=\"row\">\n                  {{i.itemname}}\n                </th>\n                <td>\n                  {{i.quantity}}\n                </td>\n                <td>\n                  {{i.costs}}\n                </td>\n                <td>\n                 {{i.tablenum}}\n                </td>\n                <td>\n                  {{i.price}}\n                 </td>\n                 <td>\n                  {{i.time}}\n                 </td>\n                 <td>\n                  {{i.status}}\n                 </td>\n                 </tr>\n              \n             \n            </tbody>\n          </table>\n        </div>\n      </div>\n    </div>\n    \n  </div> -->\n  <div *ngIf=\"load\">\n    <ion-spinner name=\"lines\"></ion-spinner>\n  </div>\n  <ion-item *ngFor=\"let i of orders\">\n    <ion-avatar slot=\"start\">\n      <img [src]=\"i.image\" />\n    </ion-avatar>\n    <ion-label>\n      <h3 class=\"mb-0\"><strong>{{i.itemname}}</strong></h3>\n      <h3>Quantity:    {{i.quantity}}</h3> \n      <h3>Total:    {{i.costs}}</h3>\n      <p>Table Number: {{i.tablenum}}</p>\n    </ion-label>\n    <ion-buttons slot=\"end\">\n      <ion-button color=\"primary\" >\n        {{i.time}}\n      </ion-button>\n      <ion-button color=\"warning\" (click)=\"deliver(i)\">\n        {{i.status}}\n      </ion-button>\n      <ion-button color=\"success\" (click)=\"sendSms(i)\">\n\n      </ion-button>\n    </ion-buttons>\n  </ion-item>\n  <div *ngIf=\"orders.length == 0\">\n    No Orders Found\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_orderlist_orderlist_module_ts.js.map