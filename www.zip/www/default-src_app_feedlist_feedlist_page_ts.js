"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_feedlist_feedlist_page_ts"],{

/***/ 329:
/*!*******************************************!*\
  !*** ./src/app/feedlist/feedlist.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeedlistPage": () => (/* binding */ FeedlistPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _feedlist_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./feedlist.page.html?ngResource */ 4600);
/* harmony import */ var _feedlist_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./feedlist.page.scss?ngResource */ 5946);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/service.service */ 58);
/* harmony import */ var _awesome_cordova_plugins_sms_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @awesome-cordova-plugins/sms/ngx */ 3974);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/toast.service */ 4465);









let FeedlistPage = class FeedlistPage {
    constructor(service, sms, alert, modalController, toast) {
        this.service = service;
        this.sms = sms;
        this.alert = alert;
        this.modalController = modalController;
        this.toast = toast;
        this.activeSegment = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('suggestion');
        this.segments = [
            { title: 'Complaints', value: 'complain' },
            { title: 'Suggestions', value: 'suggestion' },
        ];
        this.complain = [];
        this.suggest = [];
    }
    ngOnInit() {
        this.getfeedback();
    }
    sendSms(mes) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            let alert = this.alert.create({
                header: "Send SMS",
                inputs: [
                    {
                        name: 'message',
                        placeholder: 'ENTER MESSAGE'
                    },
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: data => {
                            console.log('Cancel clicked');
                        }
                    },
                    {
                        text: 'SUBMIT',
                        handler: data => {
                            let body = {
                                number: mes.phone,
                                message: data.message
                            };
                            this.service.post(body, "sms").subscribe((res) => {
                                if (res.success === true) {
                                    this.toast.presentToast("Success");
                                }
                            });
                        }
                    }
                ]
            });
            (yield alert).present();
        });
    }
    dismiss() {
        this.modalController.dismiss();
    }
    call(item) {
        window.open('tel:' + item.phone);
    }
    contact(mes) {
        // Send a text message using default options
        //this.sms.send('+233248616502', 'Hello world!');
        let body = {
            number: mes.phone,
            message: ""
        };
        this.service.post(body, "sms").subscribe((res) => {
            if (res.success === true) {
                this.toast.presentToast("Success");
            }
        });
    }
    getfeedback() {
        this.service.get("getfeedback").subscribe((response) => {
            if (response.success === true) {
                this.complain = [];
                this.suggest = [];
                for (let post of response.results) {
                    if (post.title === "suggestions") {
                        this.suggest.push(post);
                    }
                    else {
                        this.complain.push(post);
                    }
                }
            }
        });
    }
};
FeedlistPage.ctorParameters = () => [
    { type: _services_service_service__WEBPACK_IMPORTED_MODULE_2__.ServiceService },
    { type: _awesome_cordova_plugins_sms_ngx__WEBPACK_IMPORTED_MODULE_3__.SMS },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_4__.ToastService }
];
FeedlistPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-feedlist',
        template: _feedlist_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_feedlist_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FeedlistPage);



/***/ }),

/***/ 58:
/*!*********************************************!*\
  !*** ./src/app/services/service.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceService": () => (/* binding */ ServiceService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 6587);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 7418);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../environments/environment */ 2340);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);







let ServiceService = class ServiceService {
    constructor(http, alertController) {
        this.http = http;
        this.alertController = alertController;
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders().set('Content-Type', 'application/json');
        this.apiUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url;
        this.server = _environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.server;
        console.log(this.apiUrl);
    }
    imgError(e) {
        e.target.src = '../../assets/icon/no-image-icon.png';
    }
    alert(header, message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: header,
                message: message,
                buttons: [
                    {
                        text: 'OK',
                        handler: () => {
                        }
                    }
                ]
            });
            alert.present();
        });
    }
    loginUser(data) {
        let API_URL = `${this.apiUrl}/login.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    post(data, file) {
        let API_URL = `${this.apiUrl}` + file + '.php';
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    get(filename) {
        //  this.url = '?_page=' + this.page_number + '&_limit=' + this.page_limit;
        let API_URL = `${this.apiUrl}` + filename + '.php';
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getId(id, file) {
        return this.http.get(`${this.apiUrl}` + file + '.php?id=' + `${id}`);
    }
    put(data, file) {
        let API_URL = `${this.apiUrl}` + file + '.php';
        return this.http.put(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    verifyUser(data) {
        let API_URL = `${this.apiUrl}/verify.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    addUser(data) {
        let API_URL = `${this.apiUrl}/register.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    updPhotoUser(data) {
        let API_URL = `${this.apiUrl}/cover.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    addItems(data) {
        let API_URL = `${this.apiUrl}/additems.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getCinfo(data) {
        let API_URL = `${this.apiUrl}/getinfo.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    updateUser(data) {
        let API_URL = `${this.apiUrl}/edituser.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    closeday(data) {
        let API_URL = `${this.apiUrl}/closeday.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    addCashout(data) {
        let API_URL = `${this.apiUrl}/cashout.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getItems() {
        let API_URL = `${this.apiUrl}/getitems.php`;
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getDItems() {
        let API_URL = `${this.apiUrl}/getditems.php`;
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getdailies() {
        let API_URL = `${this.apiUrl}/dailies.php`;
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    addsales(data) {
        let API_URL = `${this.apiUrl}/sellitem.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getsales() {
        let API_URL = `${this.apiUrl}/loadsales.php`;
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    addexpense(data) {
        let API_URL = `${this.apiUrl}/expenses.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    setup(data) {
        let API_URL = `${this.apiUrl}/setup.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    productkey(data) {
        let API_URL = `${this.apiUrl}/productkey.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    deleteItem(data) {
        let API_URL = `${this.apiUrl}/delete_item.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    returnItem(data) {
        let API_URL = `${this.apiUrl}/return.php`;
        return this.http.post(API_URL, data)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getUsers() {
        let API_URL = `${this.apiUrl}/getUsers.php`;
        return this.http.get(API_URL)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getsingleitem(itemnum) {
        let API_URL = `${this.apiUrl}/singleitem.php`;
        return this.http.post(API_URL, itemnum)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(this.error));
    }
    getcustomer(id) {
        return this.http.get(`${this.apiUrl}/loadsinglecustomer.php?id=${id}`, id);
    }
    // Handle Errors 
    error(error) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            errorMessage = error.error.message;
        }
        else {
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.log(errorMessage);
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.throwError)(errorMessage);
    }
};
ServiceService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController }
];
ServiceService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injectable)({
        providedIn: 'root'
    })
], ServiceService);



/***/ }),

/***/ 4465:
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ToastService": () => (/* binding */ ToastService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 3819);



let ToastService = class ToastService {
    constructor(toastController) {
        this.toastController = toastController;
    }
    presentToast(infoMessage) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: infoMessage,
                duration: 2000,
                position: 'top'
            });
            toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ToastController }
];
ToastService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], ToastService);



/***/ }),

/***/ 5946:
/*!********************************************************!*\
  !*** ./src/app/feedlist/feedlist.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmZWVkbGlzdC5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 4600:
/*!********************************************************!*\
  !*** ./src/app/feedlist/feedlist.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"dismiss()\">\n        <ion-icon name=\"close\" color=\"success\">\n\n      </ion-icon> </ion-button>\n    </ion-buttons>\n    <ion-title>feedlist</ion-title>\n  </ion-toolbar>\n  <ion-segment [formControl]=\"activeSegment\" scrollX=\"true\">\n    <ion-segment-button value=\"complain\">\n      <ion-tab-button>\n        <ion-icon name=\"chatbubbles\"></ion-icon>\n      <ion-label>{{'Complain'}}</ion-label>\n    </ion-tab-button>\n     </ion-segment-button>\n    <ion-segment-button value=\"suggestion\">\n      <ion-tab-button>\n        <ion-icon name=\"chatbubbles-outline\"></ion-icon>\n      <ion-label>{{'Suggestion'}}</ion-label>\n    </ion-tab-button>\n    </ion-segment-button>\n   \n   \n     </ion-segment>\n</ion-header>\n\n<ion-content>\n  <div *ngIf=\"activeSegment.value === 'suggestion'\">\n    <ion-card class=\"post-list-card\" *ngFor=\"let message of suggest;\">\n      <ion-item lines=\"none\" >\n        <ion-avatar slot=\"start\">\n          <img src=\"./assets/images/client1.jpg\" width=\"96px\">\n        </ion-avatar>\n        <ion-label>\n          {{message.title}}  from {{message.phone}}\n          <p>{{message.date}} {{message.time}}</p>\n        </ion-label>\n        <ion-buttons slot=\"end\">\n          \n          <a href=\"tel:{{message.phone}}\"> \n            <ion-icon slot=\"icon-only\" md=\"call\" ios=\"call\"></ion-icon></a>\n          <ion-button color=\"medium\" (click)=\"sendSms(message)\">\n            <ion-icon name=\"mail-outline\"></ion-icon>\n          </ion-button>\n        </ion-buttons>\n      </ion-item>\n      <ion-card-content class=\"post-list-content\">\n      \n        <ion-label>\n          {{message.message}}\n        </ion-label>\n        \n      </ion-card-content>\n      </ion-card>\n    </div>\n    <div *ngIf=\"activeSegment.value === 'complain'\">\n      <ion-card class=\"post-list-card\" *ngFor=\"let message of complain;\">\n        <ion-item lines=\"none\" >\n          <ion-avatar slot=\"start\">\n            <img src=\"./assets/images/client1.jpg\" width=\"96px\">\n          </ion-avatar>\n          <ion-label>\n            {{message.title}}  from {{message.phone}}\n            <p>{{message.date}} {{message.time}}</p>\n          </ion-label>\n          <ion-buttons slot=\"end\">\n           \n            <a href=\"tel:{{message.phone}}\"> \n              <ion-icon slot=\"icon-only\" md=\"call\" ios=\"call\"></ion-icon></a>\n              <ion-button color=\"medium\" (click)=\"sendSms(message)\">\n                <ion-icon name=\"mail-outline\"></ion-icon>\n              </ion-button>\n          </ion-buttons>\n        </ion-item>\n        <ion-card-content class=\"post-list-content\">\n        \n          <ion-label>\n            {{message.message}}\n          </ion-label>\n          \n        </ion-card-content>\n        </ion-card>\n      </div>\n  \n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_feedlist_feedlist_page_ts.js.map